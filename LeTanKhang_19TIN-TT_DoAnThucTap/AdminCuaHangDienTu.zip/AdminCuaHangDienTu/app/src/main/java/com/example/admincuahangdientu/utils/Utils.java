package com.example.admincuahangdientu.utils;


public class Utils {
    public static String BASE_URL ="https://appelectronicstore.000webhostapp.com/AdminStore/";
    public static String BASE_IMG = "https://appelectronicstore.000webhostapp.com/Hinhanh/" ;

}

package com.example.admincuahangdientu.model;

public class Admin {
    int id;
    String tenadmin;
    String sdtadmin;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTenadmin() {
        return tenadmin;
    }

    public void setTenadmin(String tenadmin) {
        this.tenadmin = tenadmin;
    }

    public String getSdtadmin() {
        return sdtadmin;
    }

    public void setSdtadmin(String sdtadmin) {
        this.sdtadmin = sdtadmin;
    }
}

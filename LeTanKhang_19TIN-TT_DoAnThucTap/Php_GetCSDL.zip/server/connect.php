<?php
	$host="localhost";
	$username="id20626762_ltkstore";
	$password="@Khangle1512";
	$database="id20626762_electronicstore";
	$conn = mysqli_connect($host,$username,$password,$database);
 	mysqli_set_charset($conn,"utf8");

	
?>

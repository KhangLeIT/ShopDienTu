package com.example.cuahangdientu.utils;

import com.example.cuahangdientu.model.UserStore;

public class Utils {

    public static String BASE_URL ="https://appelectronicstore.000webhostapp.com/server/";

    public static UserStore user_current = new UserStore();

}

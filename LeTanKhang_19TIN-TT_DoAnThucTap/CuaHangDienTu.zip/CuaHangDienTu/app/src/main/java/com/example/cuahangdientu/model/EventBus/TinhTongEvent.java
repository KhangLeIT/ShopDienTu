package com.example.cuahangdientu.model.EventBus;

public class TinhTongEvent {
}

package com.example.cuahangdientu.model;

public class ThongBao {
    int idthongbao;
    int iduser;
    String noidungthongbao;
    int iddonhang;
    int trangthaidoc;

    public int getIdthongbao() {
        return idthongbao;
    }

    public void setIdthongbao(int idthongbao) {
        this.idthongbao = idthongbao;
    }

    public int getIduser() {
        return iduser;
    }

    public void setIduser(int iduser) {
        this.iduser = iduser;
    }

    public String getNoidungthongbao() {
        return noidungthongbao;
    }

    public void setNoidungthongbao(String noidungthongbao) {
        this.noidungthongbao = noidungthongbao;
    }

    public int getIddonhang() {
        return iddonhang;
    }

    public void setIddonhang(int iddonhang) {
        this.iddonhang = iddonhang;
    }

    public int getTrangthaidoc() {
        return trangthaidoc;
    }

    public void setTrangthaidoc(int trangthaidoc) {
        this.trangthaidoc = trangthaidoc;
    }
}
